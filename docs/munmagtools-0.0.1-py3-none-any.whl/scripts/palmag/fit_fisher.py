import sys
import pandas as pd
import argparse # handles command line arguments

from src.munmagtools.palmag.fileio import read_palmag_data, write_palmag_results
from src.munmagtools.palmag.calc import fisher_mean
from src.munmagtools.helpers import abbreviate_character_sequence

#pd.set_option('expand_frame_repr', False) # avoids linebreak within pandas output
#pd.set_option('max_column', 25)

# TODO: potentially implement line and great circle fit

parser = argparse.ArgumentParser(description='Do fisher mean of clustered directions in demagnetization data files.')
parser.add_argument('-cf', '--control-file', help='name of control file', required=True)
parser.add_argument('-of', '--output-file', default='output.txt', help='name of outputfile (output.txt if not specified)')
args = parser.parse_args()

print( "reading control file: {}".format(args.control_file))
try:
    control = pd.read_csv(args.control_file, sep=";")
except FileNotFoundError:
    print('control file not found.')
    sys.exit()

# controlfile format
# filename;component;start;stop;exclude

# read input data from all files listed in control
for l in control.iterrows():
    try:
        pmagfiledata = read_palmag_data(l[1]['filename'])['d']
        print("reading data file: {}".format(l[1]['filename']))
    except IOError:
        print("file {} not found. ignoring.".format(l[1]['filename']))
        continue

    # remove unwanted steps (outside start-stop and exlcuded ones)
    pmagfiledata = pmagfiledata[(pmagfiledata['step'] >= l[1]['start']) & (pmagfiledata['step'] <= l[1]['stop'])
                                & (~pmagfiledata['step'].isin([] if not type(l[1]['exclude'])==str else [int(s) for s in l[1]['exclude'].split('/')]))]
    pmagfiledata['component'] = l[1]['component']  # write component defined in control file to component column

    try:
        inputdata = pd.concat( [inputdata, pmagfiledata])  # append data to existing dataframe
    except NameError:  # inputdata doesn't exist
        inputdata = pmagfiledata

# calculate fisher means for geographic and tilt corrected directions
sd1 = fisher_mean(inputdata, groupby='sample', colD='D1', colI='I1', col_agg_1st='component')
sd2 = fisher_mean(inputdata, groupby='sample', colD='D2', colI='I2', col_agg_join='alphastep')

sd2['abbr_alphastep'] = sd2['alphastep'].apply(abbreviate_character_sequence)

# create table for output to file: samplename, fitting type, component, D1, I1, D2, I2, analyzed alphanumeric steps, N, a95
sd = pd.concat([sd1[['component', 'D1', 'I1']], sd2[['D2','I2','abbr_alphastep', 'N', 'a95']]], axis=1)
sd.insert(0, 'type', 'F')
sd.reset_index(level=0, inplace=True)  # remove index to treat sample as a regular column

write_palmag_results(args.output_file, sd)  # write results to file
print("results written to {}".format(args.output_file))




