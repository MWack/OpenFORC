class OutOfRangeError(ValueError):
    pass
