# gps2strat
# convert gps coordinates to stratigraphic heights for given bedding
# written by Michael Wack 2014


import utm
import numpy as np
import csv


# indices of csv columns

'''
fname = 'qimugen_automag_import.csv'
nameidx = 3
latidx = 11
lonidx = 12
altidx = 13


# dipdir and dip define the bedding plane
dipdir = 25 # 0 = northwards
dip = 24 # positive values point downwards
'''

'''
fname = 'tuoyun.csv'
nameidx = 2
latidx = 13
lonidx = 14
altidx = 15
'''


fname = 'tuoyun_p_etrex.csv'
nameidx = 0
latidx = 1
lonidx = 2
altidx = 3



dipdir = 52.3
dip = 42.0


# x towards east, right
# y towards north, up
# z downwards

# horizontal component
h = np.cos( np.deg2rad( dip-90))
# normal vector of plane
n0 = np.array(( h*np.sin( np.deg2rad( dipdir)), h*np.cos( np.deg2rad( dipdir)), np.sin( np.deg2rad( dip-90))))

# sense of normal vector changes sign of resulting stratigraphy
# make sure that normal vector is pointing downwards
if n0[2] > 0:
    n0 = -n0

# normalize
n0 = n0 / np.linalg.norm( n0)

# list of gps points (latitude, longitude, altitude)

#geopoints = (
#    (48, 33.5, 1700),
#    (48.1, 33.51, 1710),
#    (48.2, 33.52, 1720)
#)

# read in points
geopoints = []
f = open( fname)
rd = csv.reader( f, delimiter='\t')
for row in rd:
    #print row
    try:
        geopoints.append( {'name': row[nameidx], 'lat': float( row[latidx]), 'lon': float( row[lonidx]), 'alt': -float( row[altidx])})
    except IndexError:
        print( "Error on row: %s" % row)

f.close()

#print geopoints

# convert GPS lat / lon to utm coordinates
# with altitude: x,y,z coordinates in meters

x0, y0, zx0, zy0  = utm.from_latlon(geopoints[0]['lat'], geopoints[0]['lon'])
# calculate distance to origin for first point
p0 = np.array( (x0, y0, geopoints[0]['alt']))
d = np.dot( p0, n0)

print( 'normal vector of bedding plane %s'% str( n0))
print( 'distance to origin: %f' % d)

xyz = []

for gp in geopoints:
    #print gp
    x, y, zx, zy  = utm.from_latlon(gp['lat'], gp['lon'])
    #print x,y
    p = np.array((x, y, gp['alt']))
    # calculate startigraphy as distance of other points to the bedding plane (going through first point) (see Hesse normal form for math)
    s = np.dot(  p, n0) - d
    print( '%s (%d,%d,%d)\t%f' % (gp['name'], p[0],p[1],p[2], s))
