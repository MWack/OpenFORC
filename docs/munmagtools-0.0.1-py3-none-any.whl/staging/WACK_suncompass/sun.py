from datetime import datetime, timedelta
from math import sin, cos, pi, atan2, atan, asin, tan
from decimal import *
# use decimal math
import dmath as dm

# written by M. Wack 2009, 2010

# calc position of the sun in the sky (floating point)
def sundec_float( lat, lon, time):
    '''calculate declination of the sun for a given geographic postion and time
    based on the procedure of the 1996 Astronomical Almanac (accurate to 0.01 deg 1950-2050).
    See also http://magician.ucsd.edu/Essentials/WebBookse112.html
    http://www.stargazing.net/kepler/sun.html'''

    # calculate days since 1.1.2000 12:00:00 as float
    td = time - datetime( 2000, 1, 1, 12, 0, 0)
    d = td.days + td.seconds / 3600.0 / 24
    
    # calc the mean longitude lm of the sun in range 0-360 deg
    j, lm = divmod( 280.460 + 0.9856474 * d, 360)
    
    # calc the mean anomaly g of the sun in range 0-360deg
    j, g = divmod( 357.528 + 0.9856003 * d, 360)
    
    # calc the ecliptic longitude le of the sun
    le = lm + 1.915 * sin( g / 180 * pi) + 0.020 * sin( 2 * g / 180 * pi)
    
    # calc obliquity of the ecliptic plane e
    e = 23.439 - 0.0000004 * d
    
    # find right ascension ra of the sun
    ra = atan2( cos( e / 180 * pi) * sin( le / 180 * pi), cos( le / 180 * pi)) * 180 / pi
    
    # find declination de of the sun
    de = asin( sin( e / 180 *pi) * sin( le / 180 * pi)) * 180 / pi
    
    # find local sidereal time in range 0-360
    j, lst = divmod( 280.46061837 + 360.98564736629 * d + lon, 360)
    
    # find hour angle of the sun in range 0-360
    j, ha = divmod( lst - ra, 360)
    
    # calc altitude alt of the sun
    alt = asin( sin( de / 180 * pi) * sin( lat / 180 * pi) + cos( lat / 180 * pi) * cos( ha / 180 * pi) * cos( de / 180 * pi)) * 180 / pi
    
    # calc azimuth az of the sun
    n = cos( ha / 180 * pi) * sin( lat / 180 * pi) - tan( de / 180 * pi) * cos( lat / 180 * pi)
    az = atan( sin( ha / 180 * pi) / n ) * 180 / pi
    if n < 0: az += 180
    az -= 180
    if az < 0: az += 360
    
    #for val in (d,  j, lm,  j,  g,  le,  e,  ra,  de,  j,  lst,  ha,  alt,  n,  az):
    #   print( "%.9f" % val), 
    #print("\n")   
    
    # return position of the sun
    return az,  alt
    
    
 # calc position of the sun in the sky (high precision using decimal modul)
def sundec_decimal( lat, lon, time):
    '''calculate declination of the sun for a given geographic postion and time
    based on the procedure of the 1996 Astronomical Almanac (accurate to 0.01 deg 1950-2050).
    See also http://magician.ucsd.edu/Essentials/WebBookse112.html
    http://www.stargazing.net/kepler/sun.html
    use at least 9 decimals to be more precise than 0.1 deg'''

    getcontext().prec = 9
    
    # convert lat, lon to Decimal
    lat,  lon = Decimal( str( lat)),  Decimal( str(lon))
    
    # get pi as decimal
    dpi = Decimal( '3.14159265358979323846264338327950288419716939937510')
    
    # calculate days since 1.1.2000 12:00:00 as float
    td = time - datetime( 2000, 1, 1, 12, 0, 0)
    d =  Decimal(td.days) + Decimal(td.seconds) /  Decimal('3600.0') / Decimal('24')
    
    # calc the mean longitude lm of the sun in range 0-360 deg
    j, lm = divmod( Decimal( '280.460') + Decimal('0.9856474') * d, 360)
    
    # calc the mean anomaly g of the sun in range 0-360deg
    j, g = divmod( Decimal( '357.528') + Decimal( '0.9856003') * d, 360)
    
    # calc the ecliptic longitude le of the sun
    le = lm + Decimal( '1.915') * dm.sin( g / 180 * dpi) + Decimal( '0.020') * dm.sin( 2 * g / 180 *  dpi)
    
    # calc obliquity of the ecliptic plane e
    e = Decimal( '23.439') - Decimal( '0.0000004') * d
    
    # find right ascension ra of the sun
    ra = dm.atan2( dm.cos( e / 180 * dpi) * dm.sin( le / 180 * dpi), dm.cos( le / 180 * dpi)) *  180 / dpi
    
    # find declination de of the sun
    de = dm.asin( dm.sin( e / 180 * dpi) * dm.sin( le / 180 * dpi)) * 180 / dpi
    
    # find local sidereal time in range 0-360
    j, lst = divmod( Decimal( '280.46061837') + Decimal( '360.98564736629') * d + lon, 360)
    
    #find hour angle of the sun in range 0-360
    j, ha = divmod( lst - ra, 360)
    
    # calc altitude alt of the sun
    alt = dm.asin( dm.sin( de / 180 * dpi) * dm.sin( lat / 180 * dpi) + dm.cos( lat / 180 * dpi) * dm.cos( ha / 180 * dpi) * dm.cos( de / 180 * dpi)) * 180 / dpi
    
    # calc azimuth az of the sun
    n = dm.cos( ha / 180 * dpi) * dm.sin( lat / 180 * dpi) - dm.tan( de / 180 * dpi) * dm.cos( lat / 180 * dpi)
    az = dm.atan( dm.sin( ha / 180 * dpi) / n ) * 180 / dpi
    if n < 0: az += 180
    az -= 180
    if az < 0: az += 360
    
    #for val in (d,  j, lm,  j,  g,  le,  e,  ra,  de,  j,  lst,  ha,  alt,  n,  az):
    #   print( "%.9f" % val), 
    #print("\n")
    
    # return position of the sun
    return az,  alt  

# main program for testing

'''
# set start time

time = datetime(2010, 4, 6, 4, 22, 0)

# show sun positions over certain time range
for t in range( 917):
    azf, altf = sundec_float( 45.76666, 0.766666, time)
    azd,  altd =   sundec_decimal( 45.76666, 0.766666, time)
    print "%s\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f"  % (str( time), altf, azf,  altd,  azd,  altf-float(altd),  azf -float( azd))
    
    time = time + timedelta( minutes = 1)
'''    
    
    
import csv
from time import strptime

# automated orienter format
# posdat = csv.reader(open("gw13.txt", "rb"), delimiter="\t")
# for data in posdat:
#     lat = float( data[11])
#     lon = float( data[12])
#     time = strptime(data[0], "%a %b %d %H:%M:%S %Y")
#     timediff = timedelta( hours = 0, minutes = 0)
#     #print lat, lon, time
#     t = datetime(*time[:6])+ timediff
#     az, alt = sundec_decimal( lat, lon, t)
#     #print "%s @ %02.6f/%03.6f--> %.1f" % (str(t), lat, lon, az)
#     sun_reading = float( data[4])
#     alpha_sun = -1
#     if sun_reading >= 0:
#         sun_pos = sun_reading-180
#         if sun_pos < 0:
#             sun_pos += 360
#         alpha_sun = float( az) + sun_pos
#         if alpha_sun > 360:
#             alpha_sun -= 360
#     data.append( '%03.1f' % alpha_sun)
#     print '\t'.join( data)

# sophie kyrgystan data
# posdat = csv.reader(open("section1_data_in.txt", "r"), delimiter="\t")
# next( posdat, None) # skip first line
#
# timediff = timedelta( hours = 6, minutes = 0)
# for data in posdat:
#     #print( data)
#     lat = float( data[6])
#     lon = float( data[7])
#
#     try:
#         time = strptime(data[4] + ' ' + data[5], "%H:%M %d.%m.%Y")
#     except ValueError:
#         continue
#
#     #print( lat, lon, time)
#     t = datetime(*time[:6])+timediff
#     az, alt = sundec_decimal( lat, lon, t)
#     #print "%s @ %02.6f/%03.6f--> %.1f" % (str(t), lat, lon, az)
#     sun_reading = float( data[3])
#     alpha_sun = -1
#     if sun_reading >= 0:
#         sun_pos = sun_reading-180
#         if sun_pos < 0:
#             sun_pos += 360
#         alpha_sun = float( az) + sun_pos
#         if alpha_sun > 360:
#             alpha_sun -= 360
#     data.append( '%03.1f' % alpha_sun)
#     dalpha = alpha_sun - float(data[1])
#     if dalpha < -180: dalpha += 360
#     elif dalpha > 180: dalpha -= 360
#     data.append('%03.1f' % dalpha)
#     print( '\t'.join( data))

    
posdat = csv.reader(open("/home/wack/data/Projekte/Kirgistan2016/Kirg_Sec1_sushi-import.csv", "r"), delimiter="\t")
next( posdat, None) # skip first line

timediff = timedelta( hours = 6, minutes = 0)
for data in posdat:
    #print( data)
    lat = float( data[9])
    lon = float( data[10])

    try:
        time = strptime(data[0], "%d.%m.%Y %H:%M")
    except ValueError:
        print('\t'.join(data))
        continue

    #print( lat, lon, time)
    t = datetime(*time[:6])+timediff
    az, alt = sundec_decimal( lat, lon, t)
    #print( lat, lon)
    sun_reading = float( data[5])
    alpha_sun = -1
    if sun_reading >= 0:
        sun_pos = sun_reading-180
        if sun_pos < 0:
            sun_pos += 360
        alpha_sun = float( az) + sun_pos
        if alpha_sun > 360:
            alpha_sun -= 360
    data.append( '%03.1f' % alpha_sun)
    dalpha = alpha_sun - float(data[6])
    if dalpha < -180: dalpha += 360
    elif dalpha > 180: dalpha -= 360
    data.append('%03.1f' % dalpha)
    print( '\t'.join( data))






