# do simulation on reference direction refinement method
# written by Michael Wack 2021


import numpy as np
import pandas as pd
import scipy.interpolate
import scipy.spatial
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.lines import Line2D

from src import munmagtools as tf
from src.munmagtools.anisotropy.tensorfit import CreateRandomTensor
from src.munmagtools.palmag.calc import gcd_dist, DIM2XYZ_np, XYZ2DIM_np
from src.munmagtools.plotting.mpl import plotEA
from src.munmagtools.transforms import RVec

# define reference directions as used by original sushibar
ref12 = [[225.0, 0.0], [45.0, 0.0], [135.0, 0.0], [315.0, 0.0], [90.0, 45.0], [270.0, -45.0], [90.0, -45.0],
         [270.0, 45.0], [0.0, -45.0], [180.0, 45.0], [0.0, 45.0], [180.0, -45.0]]
ref6 = [[45.0, 0.0], [135.0, 0.0], [90.0, 45.0], [90.0, -45.0], [0.0, -45.0], [0.0, 45.0]]
# jelinek 15
ref15 = [[135.0, 0.0], [45.0, 0.0], [0.0, 0.0], [315.0, 0.0], [225.0, 0.0],
         [270.0, 45.0], [90.0, 45.0], [90.0, 0.0], [90.0, -45.0], [270.0, -45.0],
         [0.0, -45.0], [0.0, 45.0], [0.0, 90.0], [180.0, 45.0], [180.0, -45.0]]
# ikosaeder
ref40iko = [[90, 82.5], [90, -82.5], [270, 82.5], [270, -82.5], [15, 52.5], [15, -52.5], [345, 52.5], [345, -52.5],
            [165, 52.5], [165, -52.5], [195, 52.5], [195, -52.5], [15, 22.5], [15, -22.5], [345, 22.5], [345, -22.5],
            [165, 22.5], [165, -22.5], [195, 22.5], [195, -22.5], [60, 30], [60, -30], [120, 30], [120, -30], [240, 30],
            [240, -30], [300, 30], [300, -30], [90, 30], [90, -30], [270, 30], [270, -30], [55, 10], [55, -10],
            [125, 10], [125, -10], [235, 10], [235, -10], [305, 10], [305, -10]]
# homogeneous set Felix
ref30 = [[45, 0], [135, 0], [225, 0, ], [315, 0], [0, 45], [0, -45], [90, 45], [90, -45], [180, 45], [180, -45],
         [270, 45], [270, -45], [15, 0], [75, 0], [105, 0], [165, 0], [195, 0], [255, 0], [285, 0], [345, 0],
         [45, 45], [45, -45], [135, 45], [135, -45], [225, 45], [225, -45], [315, 45], [315, -45], [0, 90], [0, -90]]

# ideal_design_matrix_vec = tf.makeDesignMatrix(ideal_ref_dirs, xyz=True)  # create design matrix for vectorial measurements
# ideal_design_matrix_scalar = tf.makeDesignMatrix(ideal_ref_dirs, xyz=False)  # create design matrix for scalar measurements
"""
#print(ideal_design_matrix_vec)
#print(ideal_design_matrix_scalar)

# create a tensor with some fabric
evals = [1.1, 1.0, 0.9]
R1 = tf.Eigenval2AnisoTensor(evals)


###### case 1: reference directions unknown but measurements precise
# create some measurement data
K1 = tf.CalcMeasurements(ideal_design_matrix_vec, R1, xyz=True)
print(K1)

# calculate tensor
R1res = tf.CalcAnisoTensor(ideal_design_matrix_vec, K1.flatten())

print(R1res)

false_ref_dirs = np.array(ideal_ref_dirs)
false_ref_dirs += np.random.randn(*false_ref_dirs.shape)*30

false_design_matrix_vec = tf.makeDesignMatrix(false_ref_dirs, xyz=True)  # create design matrix for vectorial measurements based on "false" ref dirs


#print(false_ref_dirs)
Kfalse = tf.CalcMeasurements(false_design_matrix_vec, R1, xyz=True)
# calculate tensor assuming ideal direction but with measurments from false ones
R1falseres = tf.CalcAnisoTensor(ideal_design_matrix_vec, Kfalse.flatten())
print(R1falseres)

R1falseresopt = tf.CalcAnisoTensorProjOptimized(ideal_ref_dirs, Kfalse.flatten(), n=5)

# show difference between (false) starting reference directions and the optimized ones returned by .ProjOptimized method

print(np.array(false_ref_dirs) - np.array(R1falseresopt['opt_ref_dirs']))


###### case 2: reference directions known but measurements flawed
#### not working, not useful
K1 = tf.CalcMeasurements(ideal_design_matrix_vec, R1, xyz=True)
print(K1)
K1 += np.random.randn(*K1.shape)*.1
print(K1)

# calculate tensor
R1res = tf.CalcAnisoTensor(ideal_design_matrix_vec, K1.flatten())
print(R1res)

R1resopt = tf.CalcAnisoTensorProjOptimized(ideal_ref_dirs, K1.flatten(), n=5)
print(R1resopt)

"""


def RandomTest(ideal_ref_dirs, altered_ref_dirs=None, real_tensor=None, ev_scatter=.8, rot_scatter=60, rot_angle=0, rot_axis=None, individual=True, n=5,
               plot=True, output=True):
    """ do a random convergence test
    input:
        ideal_ref_dirs: array Nx2 of D,I pairs for N reference directions
        altered_ref_dirs: if specified use those and not randomly created ones
        real_tensor: if specified use this tensor and not a random one
        evscatter: eigen values of initial fabric will be up to 1+-evscatter
        rot_scatter: reference directions used for acquisition are scattered up to degrees
    """

    if real_tensor is not None:
        Rrand = real_tensor
    else:
        Rrand = CreateRandomTensor(ev_scatter)

    # calculate results from tensor
    aniso_dict_start = {}
    tf.AnisotropyTensor2Results(Rrand, aniso_dict_start)

    if altered_ref_dirs is not None:
        false_ref_dirs = np.array(altered_ref_dirs)
    else:
        false_ref_dirs = AlterRefDirections(ideal_ref_dirs, rot_scatter=rot_scatter, rot_angle=rot_angle, rot_axis=rot_axis,
                                        individual=individual)

    if output:
        print(f'initial fabric: {aniso_dict_start}')
        print(f'ideal ref dirs: {ideal_ref_dirs}')
        print(f'false ref dirs: {false_ref_dirs.tolist()}')

    # calculate readings expected from those false ref dirs
    false_design_matrix_vec = tf.makeDesignMatrix(false_ref_dirs, xyz=True)
    Kfalse = tf.CalcMeasurements(false_design_matrix_vec, Rrand, xyz=True)

    # use those readings to calculate the tensor fit based on the assumed ideal ref dirs
    aniso_dict_opt = tf.CalcAnisoTensorProjOptimized(ideal_ref_dirs, Kfalse.flatten(), n=n,
                                                     history=True)  # keep history for plotting

    # show difference between (false) starting reference directions and the optimized ones returned by ProjOptimized method
    # calculate great circle distance between ideal and false directions
    frd = pd.DataFrame(np.array(false_ref_dirs), columns=['D1', 'I1'])

    gcd = []
    for idx, d in enumerate(aniso_dict_opt['history']['refDirs']):
        rdh = pd.DataFrame(d, columns=['D2', 'I2'])
        gcd.append(gcd_dist(pd.concat([frd, rdh], axis=1), oCol_GCD=f"S{idx}").drop(["D1", "D2", "I1", "I2"], axis=1))

    gcd_table = pd.concat(gcd, axis=1)

    # determine iteration step when all great circle distances converge below .1°
    converged_step_indices = gcd_table.max().index[gcd_table.max() < 0.5].to_list()
    if len(converged_step_indices) == 0:
        convergence_step = -1  # did not converge within n steps
    else:
        convergence_step = gcd_table.columns.get_loc(converged_step_indices[0])
    # print(convergence_step)

    # for r in ('P', 'L', 'F'):
    #    print(f"{r}: {aniso_dict_start[r]} -> {aniso_dict_opt[r]}\n")

    # print(gcd_table.T)

    # maximum initial angular deviation
    # print(gcd_table)
    mad = gcd_table.iloc[:, 0].max()
    # print(gcd_table)

    if output:
        print("real eigenvalues")
        print(aniso_dict_start['n_eigvals'])
        print("real eigenvectors")
        print(aniso_dict_start['D1'], aniso_dict_start['I1'])
        print(aniso_dict_start['D2'], aniso_dict_start['I2'])
        print(aniso_dict_start['D3'], aniso_dict_start['I3'])
        print("projected eigenvalues")
        print(aniso_dict_opt['history']['proj'][0]['n_eigvals'])
        print("projected eigenvectors")
        print(aniso_dict_opt['history']['proj'][0]['D1'], aniso_dict_opt['history']['proj'][0]['I1'])
        print(aniso_dict_opt['history']['proj'][0]['D2'], aniso_dict_opt['history']['proj'][0]['I2'])
        print(aniso_dict_opt['history']['proj'][0]['D3'], aniso_dict_opt['history']['proj'][0]['I3'])
        print("projected P")
        print(aniso_dict_opt['history']['proj'][0]['P'])
        print("projected T")
        print(aniso_dict_opt['history']['proj'][0]['T'])
        print("vectorial eigenvalues")
        print(aniso_dict_opt['history']['vect'][0]['n_eigvals'])
        print("vectorial eigenvectors")
        print(aniso_dict_opt['history']['vect'][0]['D1'], aniso_dict_opt['history']['vect'][0]['I1'])
        print(aniso_dict_opt['history']['vect'][0]['D2'], aniso_dict_opt['history']['vect'][0]['I2'])
        print(aniso_dict_opt['history']['vect'][0]['D3'], aniso_dict_opt['history']['vect'][0]['I3'])
        print("vectorial P")
        print(aniso_dict_opt['history']['vect'][0]['P'])
        print("vectorial T")
        print(aniso_dict_opt['history']['vect'][0]['T'])

        print(f"convergence step: {convergence_step}")
        print(f"maximum angular deviation of reference directions: {mad}")
        print(f"real P: {aniso_dict_start['P']}")
        print(f"real T: {aniso_dict_start['T']}")
        print(f"optimised P: {aniso_dict_opt['P']}")
        print(f"optimised T: {aniso_dict_opt['T']}")
        print(f"optimised eigenvalues: {aniso_dict_opt['n_eigvals']}")
        print("optimised eigenvectors")
        print(aniso_dict_opt['D1'], aniso_dict_opt['I1'])
        print(aniso_dict_opt['D2'], aniso_dict_opt['I2'])
        print(aniso_dict_opt['D3'], aniso_dict_opt['I3'])

        print(f"proj P: {aniso_dict_opt['history']['proj'][0]['P']}")
        print(f"vect P: {aniso_dict_opt['history']['vect'][0]['P']}")

    if plot:
        # print(aniso_dict_opt['history'])
        fig, axs = plt.subplots(2)

        gcd_table.T.plot(ax=axs[0])

        axs[0].set_xlabel("iteration step")
        axs[0].set_ylabel("great circle distance")
        plt.suptitle("convergence")

        hp = pd.DataFrame(aniso_dict_opt['history']['proj'])
        hv = pd.DataFrame(aniso_dict_opt['history']['vect'])
        axs[1].plot(range(len(hp)), hp['P'] - aniso_dict_start['P'], label="Pproj")
        axs[1].plot(range(len(hp)), hp['T'] - aniso_dict_start['T'], label="Tproj")
        axs[1].plot(range(len(hp)), hv['P'] - aniso_dict_start['P'], label="Pvect")
        axs[1].plot(range(len(hp)), hv['T'] - aniso_dict_start['T'], label="Tvect")
        axs[1].legend()
        axs[1].set_xticks(range(len(hp)))
        # plt.show()

        hs = aniso_dict_start
        ho = aniso_dict_opt
        hp = aniso_dict_opt['history']['proj'][0]
        hv = aniso_dict_opt['history']['vect'][0]

        colors = ['red', 'green', 'blue', 'orange']
        labels = ['true', 'refined', 'projection', 'vectorial']

        fig = plotEA([[hs['D1'], hs['D2'], hs['D3']],
                [ho['D1'], ho['D2'], ho['D3']],
                [hp['D1'], hp['D2'], hp['D3']],
                [hv['D1'], hv['D2'], hv['D3']]],
               [[hs['I1'], hs['I2'], hs['I3']],
                [ho['I1'], ho['I2'], ho['I3']],
                [hp['I1'], hp['I2'], hp['I3']],
                [hv['I1'], hv['I2'], hv['I3']]],
               is_aniso=[True, True, True, True], colors=colors)

        #add custom legend
        legend_elements = [Line2D([0], [0], marker='o', color=c, label=l, markerfacecolor=c, markersize=15) for (c, l) in zip(colors, labels)]
        fig.gca().legend(handles=legend_elements, loc='upper right', bbox_to_anchor=(1.25, 1.05))

        plt.show()

    if aniso_dict_opt['T'] == 0:
        print("###############")
        print(aniso_dict_opt['eigvals'])

    return {"convergence_step": convergence_step, "mad": mad, "realP": aniso_dict_start['P'],
            "optP": aniso_dict_opt['P'], "projP": aniso_dict_opt['history']['proj'][0]['P'],
            "vectP": aniso_dict_opt['history']['vect'][0]['P'],
            "realT": aniso_dict_start['T'], "optT": aniso_dict_opt['T'], "projT": aniso_dict_opt['history']['proj'][0]['T'],
            "vectT": aniso_dict_opt['history']['vect'][0]['T'],
            "D1R": aniso_dict_start['D1'], "I1R": aniso_dict_start['I1'],  # real fabric
            "D2R": aniso_dict_start['D2'], "I2R": aniso_dict_start['I2'],
            "D3R": aniso_dict_start['D3'], "I3R": aniso_dict_start['I3'],
            "D1P": aniso_dict_opt['history']['proj'][0]['D1'], "I1P": aniso_dict_opt['history']['proj'][0]['I1'],
            # initial result from projection method
            "D2P": aniso_dict_opt['history']['proj'][0]['D2'], "I2P": aniso_dict_opt['history']['proj'][0]['I2'],
            "D3P": aniso_dict_opt['history']['proj'][0]['D3'], "I3P": aniso_dict_opt['history']['proj'][0]['I3'],
            "D1V": aniso_dict_opt['history']['vect'][0]['D1'], "I1V": aniso_dict_opt['history']['vect'][0]['I1'],
            # initial result from vectorial method
            "D2V": aniso_dict_opt['history']['vect'][0]['D2'], "I2V": aniso_dict_opt['history']['vect'][0]['I2'],
            "D3V": aniso_dict_opt['history']['vect'][0]['D3'], "I3V": aniso_dict_opt['history']['vect'][0]['I3'],
            "D1O": aniso_dict_opt['D1'], "I1O": aniso_dict_opt['I1'],  # results from optimized method
            "D2O": aniso_dict_opt['D2'], "I2O": aniso_dict_opt['I2'],
            "D3O": aniso_dict_opt['D3'], "I3O": aniso_dict_opt['I3']}


def AlterRefDirections(ideal_ref_dirs, rot_scatter=60, rot_angle=0, rot_axis=None, individual=True):
    """
    Alterate array of given reference directions

    params:
        ideal_ref_dirs: list with [D,I] pairs for each direction
        rot_scatter: maximum random rotation angle in degrees
        rot_angle: systematic rotation in degrees
        rot_axis: None: random rotation axis for each direction or array of 3 values (x,y,z) to specify rotation axis
        individual: if true use individual random values for each direction, if false use same rotation on all directions

    returns:
        array of altered reference directions
    """

    ideal_ref_dirs_xyz = DIM2XYZ_np(*np.array(ideal_ref_dirs).T).T

    if individual:  # rotate every direction around random axis by individual random angle
        # make sure all individual rotations are below a random threshold
        rot_scatter_limit = np.random.random_sample() * rot_scatter
        false_ref_dirs_xyz = []
        for rd in ideal_ref_dirs_xyz:
            R = scipy.spatial.transform.Rotation.from_rotvec(RVec(rot_scatter_limit, rot_angle, rot_axis, normal=False))
            false_ref_dirs_xyz.append(R.apply(rd))
        false_ref_dirs_xyz = np.array(false_ref_dirs_xyz)
    else:
        R = scipy.spatial.transform.Rotation.from_rotvec(RVec(rot_scatter, rot_angle, rot_axis, normal=False))
        false_ref_dirs_xyz = R.apply(ideal_ref_dirs_xyz)

    # calculate D and I from x,y and z
    false_ref_dirs = XYZ2DIM_np(*false_ref_dirs_xyz.T)[0:2].T
    return false_ref_dirs


def RunAnisotropyExperiments(ideal_ref_dirs, no=1000, n=10, rot_scatter=90, ev_scatter=0.7, rot_angle=0, rot_axis=None,
                             individual=False):
    res = []
    for i in range(no):
        print(f"\r{i / no * 100:3.0f}%", end='')  # progress indicator
        res.append(RandomTest(ideal_ref_dirs=ideal_ref_dirs, ev_scatter=ev_scatter, rot_scatter=rot_scatter,
                              rot_angle=rot_angle, rot_axis=rot_axis,
                              individual=individual, n=n, plot=False, output=False))

    # convergence step, max starting angular deviation, initial P
    res = pd.DataFrame(res)  # make pandas data frame with one column per result

    # print(res[res['mad'] < 1])
    # plotting
    fig, ax1 = plt.subplots(1)
    fig.suptitle(
        f"ndir={len(ideal_ref_dirs)}, n={no}, max_iter={n}, ev+-{ev_scatter},\n dir+-{rot_scatter}°, rot_angle={rot_angle}, rot_axis={rot_axis}, indi={individual}")

    vals = np.ones((n, 4))
    vals[:, 0] = 0
    vals[:, 1] = np.linspace(.2, .8, n)  # green shades
    vals[:, 2] = 0
    cmap = ListedColormap(vals)
    cmap.set_under('red')  # show not converged points (i.e. res[:, 0] == -1) in red

    im = ax1.scatter(res['realP'], res['mad'], c=res['convergence_step'], marker='.', s=5, edgecolor='face', cmap=cmap,
                     vmin=0, vmax=n)
    ax1.set_ylim([0, res['mad'].max()+1])
    ax1.set_xlabel("true P")
    ax1.set_ylabel("maximum gcd of reference directions [°]")
    fig.colorbar(im, ax=ax1, extend='min')  # , ticks=range(0, n))

    # show histogram of convergence steps
    plt.figure(2)
    bins = range(-1, n + 1)
    # res['convergence_step'].hist(bins=bins, align="left", rwidth=.6)
    dat, bins, patches = plt.hist(res['convergence_step'], bins=bins, align='left', color='g')
    patches[0].set_fc('r')  # make first bin red
    plt.xticks(bins)
    plt.xlabel('steps to convergence')
    plt.ylabel('counts')

    # plot anisotropy parameter P
    fig, axs = plt.subplots(3, sharex=True, sharey=True)
    s = 5
    c = res['convergence_step']  # ['red' if cs == -1 else 'green' for cs in res['convergence_step']]
    axs[0].scatter(res['realP'], res['projP'], c=c, s=s, marker='.', label='proj P', cmap=cmap, vmin=0, vmax=n)
    axs[1].scatter(res['realP'], res['vectP'], c=c, s=s, marker='.', label='vect P', cmap=cmap, vmin=0, vmax=n)
    axs[2].scatter(res['realP'], res['optP'], c=c, s=s, marker='.', label='opt P', cmap=cmap, vmin=0, vmax=n)

    for ax in axs.flat:
        ax.set(ylim=[1, 10], xlim=[1, 6])
        ax.plot([1, 10], [1, 10], c='gray', linestyle=':', linewidth=1)  # 1:1 line

    axs[0].set_ylabel('projected')
    axs[1].set_ylabel('vectorial')
    axs[2].set_ylabel('refined')
    axs[2].set_xlabel('true P')

    plt.suptitle('degree of anisotropy P')

    # plot anisotropy parameter T
    fig, axs = plt.subplots(3, sharex=True, sharey=True)
    s = 5
    c = res['convergence_step']  # ['red' if cs == -1 else 'green' for cs in res['convergence_step']]
    axs[0].scatter(res['realT'], res['projT'], c=c, s=s, marker='.', label='proj P', cmap=cmap, vmin=0, vmax=n)
    axs[1].scatter(res['realT'], res['vectT'], c=c, s=s, marker='.', label='vect P', cmap=cmap, vmin=0, vmax=n)
    axs[2].scatter(res['realT'], res['optT'], c=c, s=s, marker='.', label='opt P', cmap=cmap, vmin=0, vmax=n)

    for ax in axs.flat:
        ax.set(ylim=[-1, 1], xlim=[-1, 1])
        #ax.plot([1, 10], [1, 10], c='gray', linestyle=':', linewidth=1)  # 1:1 line

    axs[0].set_ylabel('projected')
    axs[1].set_ylabel('vectorial')
    axs[2].set_ylabel('refined')
    axs[2].set_xlabel('true T')

    plt.suptitle('shape parameter T')

    # plot angular deviation of eigenvectors

    fig, axs = plt.subplots(3, sharex=True, sharey=True)
    s = 5
    c = res['convergence_step']

    # calculate and plot angular distances of eigenvectors from initial scalar and vectorial calculation to real directions
    # mark = {'1': '+', '2': 'x'}
    ax_idx = {'P': 0, 'V': 1, 'O': 2}
    for idx in '123':
        for pv in ['P', 'V', 'O']:  # projected, vectorial, optimised
            gcd_dist(res, iCol_d1=f"D{idx}R", iCol_i1=f"I{idx}R", iCol_d2=f"D{idx}{pv}", iCol_i2=f"I{idx}{pv}",
                     oCol_GCD=f"GCD{idx}{pv}")

            axs[ax_idx[pv]].scatter(res['realP'], res[f"GCD{idx}{pv}"], c=c, s=s, marker=idx, label=f"EV{idx}",
                                    cmap=cmap,
                                    vmin=0, vmax=n)

    for ax in axs.flat:
        ax.set_yticks([0, 90, 180])
        # ax.legend()
        ax.label_outer()

    #axs[0].legend()
    axs[0].set_ylabel('projected')
    axs[1].set_ylabel('vectorial')
    axs[2].set_ylabel('refined')
    axs[2].set_xlabel('true P')

    plt.suptitle('gcd deviation of eigenvectors')

    plt.show()

def PlotRefDirs(ref_dirs):
    d, i = list(zip(*ref_dirs))

    fig = plotEA([list(d), ], [list(i), ], lower=False, title='Reference Directions')

    plt.show()

print( 'running munmagtools/staging/WACK_ANISOTROPY_REFINEMENT/ani_refine.py')
#RunAnisotropyExperiments(ideal_ref_dirs=ref6, no=10000, n=20, rot_scatter=50, ev_scatter=0.7, rot_angle=0, rot_axis=None, individual=True)


# random examples
#RandomTest(ref6, ev_scatter=.7, rot_scatter=50, rot_angle=0, rot_axis=None, individual=True, n=20, plot=True)

# case A example
#print('case A')
#ar = [[50.0, 0], [130.0, 0], [90.0, 45.0], [85.0, -45.0], [5.0, -45.0], [0.0, 45.0]]
#RandomTest(ref6, altered_ref_dirs=ar, real_tensor=tf.Eigenval2AnisoTensor([1.1, 0.96, 0.94]), rot_scatter=0, rot_angle=0, rot_axis=None, individual=True, n=20, plot=True)

# case B example
#print('case B')
#ar = [[35.0, 5.0], [135.0, -5.0], [85.0, 55.0], [95.0, -40.0], [0.0, -40.0], [5.0, 45.0]]
#R = RotateTensor(tf.Eigenval2AnisoTensor([1.7, 1.6, 0.55]), scipy.spatial.transform.Rotation.from_rotvec(np.array((22, 44, 76))).as_matrix())
#RandomTest(ref6, altered_ref_dirs=ar, real_tensor=R, rot_scatter=0, rot_angle=0, rot_axis=None, individual=True, n=20, plot=True)

# case C example
#print('case C')
#ar = [[40, -5], [130, -10], [95, 35.0], [80.0, -50.0], [355, -40.0], [10.0, 50.0]]
#R = RotateTensor(tf.Eigenval2AnisoTensor([1.6, 0.8, 0.4]), scipy.spatial.transform.Rotation.from_rotvec(np.array((34, 22, 19))).as_matrix())
#RandomTest(ref6, altered_ref_dirs=ar, real_tensor=R, rot_scatter=0, rot_angle=0, rot_axis=None, individual=True, n=20, plot=True)


#PlotRefDirs(ref6)
#plotEA([[4,], ], [[23,], ])
#plt.show()

print( tf.makeDesignMatrix(ref6, xyz=False))