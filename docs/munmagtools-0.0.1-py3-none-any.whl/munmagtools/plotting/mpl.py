# this is part of munmagtools
# written by M. Wack 2021
# based on automag code
# provides basic plotting with matplotlib

import matplotlib

import matplotlib.pyplot as plt
import math
import numpy as np


def inc2radius(I, proj='earea'):
    """
    :param I: convert inclination in degrees to radius on polarplot
    :return:
    """
    # from Statistics of Earth Science Data: Their Distribution in Time, Space and Orientation
    # Graham J. Borradaile

    i = abs(I)

    if proj == 'earea':  # equal area
        return 90 * (math.sqrt(2) * math.sin(math.radians((90 - i) / 2)))
    elif proj == 'eangle':  # equal angle
        return 90 * math.tan(math.radians((90 - i) / 2))


def plotEA(decs=None, incs=None, title=None, legend_labels=None, is_aniso=None, sizes=None, colors=None, lower=True):
    # plot an equal area net
    # if lower == True, project all directions to lower hemisphere
    matplotlib.rc('grid', color='black', linewidth=1, linestyle='-')
    matplotlib.rc('xtick', labelsize='small')

    # matplotlib.rc('tick', labelsize=12)

    fig = plt.figure()
    ax = fig.add_axes([0.1, 0.1, 0.8, 0.8], projection='polar')#, axis_bgcolor='white')

    if not (decs == None or incs == None):
        ''' if is_aniso == True -> use only first three direction and use typical aniso symbols i.e. circle, triangle, square '''

        if len(decs) != len(incs):
            print('number of datasets of incs and decs must be identical')
            return

        if len(decs) == 0:
            print('nothing to plot')
            return

        if lower:  # TODO: make this more efficient
            # project everything to lower hemisphere
            for c in range(len(incs)):
                for i in range(len(incs[c])):
                    if incs[c][i] < 0:  # upper hemisphere
                        incs[c][i] *= -1
                        decs[c][i] = (decs[c][i]+180) % 360  # flip direction

        #ax = fig.gca()


        # plot data points
        pl = []
        if colors is not None:
            ecols = colors
        else:
            ecols = ['black', 'red', 'green', 'blue', 'yellow']
        ecol = 'black'  # use black as default

        for c in range(len(decs)):
            fcol = 'none'  # face colors
            marker = 'o'

            if sizes == None or len(sizes) <= c:  # set size for all symbols in one group (i.e. 3 x anisotropy)
                size = 20  # default size
            else:
                size = sizes[c]  # use size as specified

            for i in range(len(decs[c])):
                # set edge color for non anisotropy plots
                #if not is_aniso[c]:
                ecol = ecols[c % len(ecols)]

                # set facecolor (hollow for upper hemisphere, filled for lower hemisphere
                if incs[c][i] >= 0:
                    fcol = ecol
                else:
                    fcol = 'none'
                    # change marker if anisotropy plot

                sizeoff = 0   # symbol size offset
                if is_aniso is not None:
                    if is_aniso[c] and i == 2:
                        marker = 'o'  # make minimum axis plot as red circle
                        if colors is None:
                            ecol = 'red'
                    if is_aniso[c] and i == 1:
                        marker = '^'  # make intermed. axis plot as green triangle
                        if colors is None:
                            ecol = 'green'
                    if is_aniso[c] and i == 0:
                        marker = 's'  # make maximum (=first axis) axis plot as blue square
                        if colors is None:
                            ecol = 'blue'
                    if is_aniso[c] and incs[c][i] >= 0:
                        fcol = ecol  # make face color = edge color in case of anisotropy
                        # ecol = 'black'
                elif incs[c][i] < 0:
                    # make symbols for negative inclinations larger, so that they can be seen on top of positive ones
                    sizeoff = size*3


                # plot one point to make different symbols for anisotropy possible
                sp = ax.scatter([math.radians(90 - decs[c][i])], [inc2radius(incs[c][i])], marker=marker,
                                facecolor=fcol, edgecolor=ecol, s=size + sizeoff)

                if is_aniso is not None:
                    if is_aniso[c] and c == 0:
                        pl.append(sp)  # keep reference of first three points for legend

                    if is_aniso[c] and i == 2:
                        break  # 3 points plotted for anisotropy -> stop here and go on to next sample

                    if not is_aniso[c] and i == 0:  # i.e. first point for sample
                        pl.append(sp)  # keep reference for legend

        #if is_aniso:  # in case of anisotropy plotting -> overide legend labels
        #    ax.legend(pl, ('max k1', 'int k2', 'min k3'), bbox_to_anchor=(1.05, 1), loc=2)
        if legend_labels is not None:
        #    # add legend
            ax.legend(pl, legend_labels, bbox_to_anchor=(1.05, 1), loc=2)

        ax.set_rmax(90.0)
        ax.set_rmin(0)
        ax.grid(linestyle=":")
        ax.grid(True)  # this is important to show the grid (according to docs it should be implicit with the call before)

        ring_angles = [15, 30, 45, 60, 75]
        #ring_angles = [90, ]
        ring_labels = [f"{x}" for x in ring_angles]
        ax.set_rgrids([inc2radius(i) for i in ring_angles], ring_labels, angle=45)
        # set declination levels; radius = 115%
        ax.set_thetagrids(range(0, 360, 90), ('90', '0', '270', '180'))#, frac=1.15)

        if title != None:
            # set title, put 15% above the figure
            ax.set_title(title, alpha=.7, size="smaller", y=1.15)

        #plt.show()
        return fig


def plotPolarContour(decs, incs, values, cmap='bwr', levels=256, title=None):
    """ make polar plot with contours out of irregular dec, inc, value arrays"""
    fig = plt.figure()

    # #hack: draw contours in cartesian coordinates
    ax = fig.add_subplot(111)
    theta = np.radians(decs+90)
    rad = 90-incs
    cs = ax.tricontourf(rad * np.cos(theta), rad * np.sin(theta), values, levels=levels, cmap=cmap)
    # cs2 = ax.tricontour(rad * np.cos(theta), rad * np.sin(theta), values, levels=10)
    ax.set_aspect('equal')
    ax.axis('off')

    # add polar axes
    ax_polar = fig.add_axes(ax.get_position(), polar=True)
    ax_polar.set_theta_zero_location("N")
    ax_polar.set_theta_direction(-1)
    ax_polar.set_facecolor('none')  # make transparent
    ax_polar.set_ylim(0, rad.max())

    #cb = fig.colorbar(cs)  # Make a colorbar for the ContourSet returned by the contourf call.
    #cb.add_lines(cs2)  # Add the contour line levels to the colorbar

    if title != None:
        # set title, put 15% above the figure
        ax.set_title(title, alpha=.7, size="smaller", y=1.15)
