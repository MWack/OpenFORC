# This is file is part of munmagtools
# palmag/calc.py


import numpy as np
import pandas as pd
import math


def DIM2XYZ_np(D, I, M=1):
    return np.array([np.cos(np.radians(I)) * np.cos(np.radians(D)), np.cos(np.radians(I)) * np.sin(np.radians(D)), np.cos(np.radians(I)) * np.tan(np.radians(I))]) * M

def DIM2XYZ(df, colD='D', colI='I', colM=None, colX='x', colY='y', colZ='z'):
    """
    adds x,y,z columns to pandas dataframe calculated from D,I,(M) columns

    Parameters
    ----------
    df: pandas dataframe
        data including columns of D, I and optionally M values
    colD: str
        name of column with declination input data
    colI: str
        name of column with inclination input data
    colM: str
        name of column with moment data (will be set to 1 if None)
    colX: str
        name of column for x data (will be created or overwritten)
    colY: str
        name of column for y data (will be created or overwritten)
    colZ: str
        name of column for z data (will be created or overwritten)

    Returns
    -------
    modified df

    """
    M = 1 if colM is None else df[colM]

    df[colX] = np.cos(np.radians(df[colI])) * np.cos(np.radians(df[colD])) * M
    df[colY] = np.cos(np.radians(df[colI])) * np.sin(np.radians(df[colD])) * M
    df[colZ] = np.cos(np.radians(df[colI])) * np.tan(np.radians(df[colI])) * M

    return df

def XYZ2DIM_np(x, y, z):
    M = np.linalg.norm([x, y, z], axis=0)  # calculate total moment for all rows
    D = np.degrees(np.arctan2(y, x)) % 360  # calculate D and map to 0-360 degree range
    I = np.degrees(np.arcsin(z / M))  # calculate I

    return np.vstack([D,I,M])


def XYZ2DIM(df, colX='x', colY='y', colZ='z', colD='D', colI='I', colM=None):
    """
    adds D,I,(M) columns to pandas dataframe calculated from x,y,z columns

    Parameters
    ----------
    df: pandas dataframe
        data including columns of x, y, z values
    colX: str
        name of column for x input data
    colY: str
        name of column for y input data
    colZ: str
        name of column for z input data
    colD: str
        name of column with declination data (will be created or overwritten)
    colI: str
        name of column with inclination data (will be created or overwritten)
    colM: str
        name of column with moment data (will not be written if None)

    Returns
    -------

    """

    M = np.linalg.norm( [df[colX], df[colY], df[colZ]], axis=0)  # calculate total moment for all rows
    df[colD] = np.degrees(np.arctan2(df[colY], df[colX])) % 360 # calculate D and map to 0-360 degree range
    df[colI] = np.degrees(np.arcsin(df[colZ] / M)) # calculate I
    if colM is not None:
        df[colM] = M # set M

def fisher_mean( inputdata, groupby='site', colD='D', colI='I', colX='x', colY='y', colZ='z', colM='M', colN='N',
                 col_a95='a95', col_k='k', col_agg_1st=None, col_agg_join=None):
    """
    Calculate a fisherian mean direction and a95 error estimate for each group of directions. Typically a group is data from one sample or site.
    Directions will be read from colD and colI columns. colX, colY and colZ will be created or overwritten in df.

    Parameters
    ----------
    inputdata: pandas dataframe
        data including columns of sample, D, I values
    groupby: str or list
        column name or list of columns for hierarchical index, default: 'site'
    colD: str
        name of column with declination input data
    colI: str
        name of column with inclination input data
    colX: str
        name of column with x output data (present in df as well as the returned dataframe)
    colY: str
        name of column with y output data (present in df as well as the returned dataframe)
    colZ: str
        name of column with z output data (present in df as well as the returned dataframe)
    colM: str
        name of column with M output data in returned dataframe
    colN: str
        name of column with N (number of entries in original group) output data in returned dataframe
    col_a95: str
        name of column with a95 output data in returned dataframe
    col_agg_1st: str
        first line in this column of each group will be transfered to returned dataframe
        e.g. 'component'
    col_agg_join: str
        joined string of all lines in this column in each group will be transfered to returned dataframe
        e.g. alphanumerical steps

    Returns
    -------
    New pandas dataframe that contains the fisherian mean directions and aggregated data for each group of original directions.

    """
    # first calculate xyz from D and I for each row and for each of the two directions
    DIM2XYZ(inputdata, colD, colI, None, colX, colY, colZ)

    gd = inputdata.groupby(groupby) # group data
    sd = gd.sum() # sum x,y,z for each group
    sd['N'] = gd.size()  # add column N which is the number of components used for the sum,

    if col_agg_1st is not None:
        sd[col_agg_1st] = gd[col_agg_1st].apply(lambda col: col.iloc[0])  # get entry from first line of group

    if col_agg_join is not None:
        sd[col_agg_join] = gd[col_agg_join].agg(lambda col: ''.join(col))  # aggregate list of alphanumerical steps for each sample

    # calculate D and I for the averaged directions (fisher means)
    XYZ2DIM(sd, colX, colY, colZ, colD, colI, colM)

    # calculate a95 uncertainty estimate
    sd[col_a95] = np.degrees(np.arccos(1 - (sd[colN] - sd[colM]) / sd[colM] * ((1 / 0.05) ** (1 / (sd[colN] - 1)) - 1)))

    # calculate precision parameter K
    sd[col_k] = (sd[colN] - 1) / (sd[colN] - sd[colM])

    # make list of columns that will be returned
    out_col_list = [colD, colI, colM, colN, col_a95, col_k]

    if col_agg_1st is not None:
        out_col_list.append(col_agg_1st)
    if col_agg_join is not None:
        out_col_list.append(col_agg_join)

    return sd[out_col_list]


def sun_pos(inputdata, col_lat='lat', col_lon='lon', col_utc_datetime_str='datetime',
            col_utc_datetime='datetime', datetimefmt="%d.%m.%Y %H:%M", timedelta="0 hours 0 minutes",
            col_sun_az='sun_az', col_sun_alt=None):
    """
    %d.%m.%Y %H:%M <-> 31.1.1999 9:38
    Calc position of the sun in the sky (declination and inclination) for a given geographic postion and time
    Based on the procedure of the 1996 Astronomical Almanac (accurate to 0.01 deg 1950-2050).
    See also http://magician.ucsd.edu/Essentials/WebBookse112.html, http://www.stargazing.net/kepler/sun.html

    Parameters
    ----------
    inputdata: pandas Dataframe
    col_lat: str
    col_lon: str
    col_utc_datetime: str
    datefmt: str
       format string for date and time in column col_utc_datetime
    timedelta:
    col_sun_az: str
    col_sun_alt: str

    Returns
    -------

    """

    # TODO: optimize calculation. do not convert between radians and degrees all the time.

    # convert existing date time strings to pandas date time using specified datetime format string (datetimefmt)
    if datetimefmt is not None:
        inputdata[col_utc_datetime] = pd.to_datetime(inputdata[col_utc_datetime_str], format=datetimefmt)

    # calculate days since 1.1.2000 12:00:00 as float
    td = inputdata[col_utc_datetime] - pd.Timestamp('2000-01-01 12:00:00') + pd.Timedelta(timedelta)
    days_since_2000 = td.dt.days + td.dt.seconds / 3600 / 24

    # calc the mean longitude lm of the sun in range 0-360 deg
    lm = (280.460 + 0.9856474 * days_since_2000) % 360

    # calc the mean anomaly g of the sun in range 0-360deg
    g = (357.528 + 0.9856003 * days_since_2000) % 360

    # calc the ecliptic longitude le of the sun
    le = lm + 1.915 * np.sin(g / 180 * np.pi) + 0.020 * np.sin(2 * g / 180 * np.pi)

    # calc obliquity of the ecliptic plane e
    e = 23.439 - 0.0000004 * days_since_2000

    # find right ascension ra of the sun
    ra = np.arctan2(np.cos(e / 180 * np.pi) * np.sin(le / 180 * np.pi), np.cos(le / 180 * np.pi)) * 180 / np.pi

    # find declination de of the sun
    de = np.arcsin(np.sin(e / 180 * np.pi) * np.sin(le / 180 * np.pi)) * 180 / np.pi

    # find local sidereal time in range 0-360
    lst = (280.46061837 + 360.98564736629 * days_since_2000 + inputdata[col_lon]) % 360

    # find hour angle of the sun in range 0-360
    ha = (lst - ra) % 360

    # calc altitude alt of the sun
    alt = np.arcsin(np.sin(de / 180 * np.pi) * np.sin(inputdata[col_lat] / 180 * np.pi) +
                    np.cos(inputdata[col_lat] / 180 * np.pi) * np.cos(ha / 180 * np.pi) *
                    np.cos(de / 180 * np.pi)) * 180 / np.pi

    # calc azimuth az of the sun
    n = np.cos(ha / 180 * np.pi) * np.sin(inputdata[col_lat] / 180 * np.pi) - np.tan(de / 180 * np.pi) * np.cos(inputdata[col_lat] / 180 * np.pi)
    az = np.arctan(np.sin(ha / 180 * np.pi) / n) * 180 / np.pi

    az = (az-180) % 360

    inputdata[col_sun_az] = az
    if col_sun_alt is not None:
        inputdata[col_sun_alt] = alt


def sun_compass(inputdata, col_lat='lat', col_lon='lon', col_utc_datetime_str='datetime', col_utc_datetime='datetime', datetimefmt="%d.%m.%Y %H:%M", timedelta='0 hours', col_sun_reading='sun', col_sun_az='sun_az', col_sun_core_az='sun_core_az'):
    """
    calculate core azimuth from sun reading at give lat/lon/time. Assumes Pomeroy type readings.

    Parameters
    ----------
    inputdata: pandas Dataframe
    col_lat: str
    col_lon: str
    col_utc_datetime_str: str
    col_utc_datetime: str
    datetimefmt: str
    col_sun_reading: str
    col_sun_az: str
    col_sun_core_az: str

    Returns
    -------

    """
    sun_pos( inputdata, col_lat=col_lat, col_lon=col_lon, col_utc_datetime_str=col_utc_datetime_str, col_utc_datetime=col_utc_datetime, datetimefmt=datetimefmt, timedelta=timedelta, col_sun_az=col_sun_az)

    inputdata[col_sun_core_az] = ((inputdata[col_sun_reading]) + inputdata[col_sun_az]) % 360

# math version - great circle distance
def GCDist(D1, I1, D2, I2):
    D1, I1, D2, I2 = math.radians(D1), math.radians(I1), math.radians(D2), math.radians(I2)
    return math.degrees(math.acos(math.sin(I1) * math.sin(I2) + math.cos(I1) * math.cos(I2) * math.cos(D2 - D1)))

# #numpy version
# #broadcasting with pairs of data not working
# @ufunc(2,1)
# def gcd_dist_np(dir1, dir2):
#     """
#     calculate great circle distance in degrees between two direction (D1,I1) and (D2,I2)
#
#     Parameters
#     ----------
#     dir1: array like D,I pairs in last dimension
#     dir2: array like D,I pairs in last dimension
#
#     Returns
#     -------
#     array with great circle distances
#
#     """
#
#     return np.degrees(np.arccos(np.sin(np.radians(dir1[1])) * np.sin(np.radians(dir2[1])) +
#                        np.cos(np.radians(dir1[1])) * np.cos(np.radians(dir2[1])) *
#                        np.cos(np.radians(dir2[0]) - np.radians(dir1[0]))))


# pandas version
def gcd_dist(inputdata, iCol_d1='D1', iCol_d2='D2', iCol_i1='I1', iCol_i2='I2', oCol_GCD='GCD'):
    """
    calculate great circle distance in degrees between two direction (D1,I1) and (D2,I2)

    Parameters
    ----------
    inputdata: pandas Dataframe
    iCol_d1: str  name of column that contains declination values of first direction
    iCol_d2: str  name of column that contains declination values of second direction
    iCol_d1: str  name of column that contains inclination values of first direction
    iCol_d2: str  name of column that contains inclination values of second direction
    oCol_GCD: str  name of column that will be filled wit great circle distances

    Returns
    -------
    modified inputdata
    """

    inputdata[oCol_GCD] = np.degrees(np.arccos((np.sin(np.radians(inputdata[iCol_i1])) * np.sin(np.radians(inputdata[iCol_i2])) +
                       np.cos(np.radians(inputdata[iCol_i1])) * np.cos(np.radians(inputdata[iCol_i2])) *
                       np.cos(np.radians(inputdata[iCol_d2]) - np.radians(inputdata[iCol_d1]))).round(decimals=4)))
    #round avoids runtime warning for values slightly outside [-1, 1] interval for arccos
    return inputdata
