# This is file is part of munmagtools
# palmag/io.py

import io
import os
import pandas as pd



def read_palmag_data(filename):
    """
    Read in data from a palmag data file which commonly contains orientation and stepwise directional demagnetization data from a single sample
    First column 'sample' contains filename without extension

    Parameters
    ----------
    filename: string
        filename including the path

    Returns
    -------
    dict
        entries 'h1' and 'h2' contain the split data from the two header lines
        'd' is the data as a pandas dataframe

    """
    with open(filename) as f:
        h1,h2 = f.readline().strip().split(), f.readline().strip().split()
        # read rest of the file as fixed width fields
        d = pd.read_fwf(io.StringIO(f.read()), skiprows=0, header=None, names=('treatment', 'step', 'D1', 'I1', 'D2', 'I2', 'M', 'a95', 'D3', 'I3', 'A', 'B', 'C'),
                        colspecs=((0,3), (3,7), (7,13), (13,19), (19,25), (25,31), (31,40), (40,46), (46,52), (52,58), (58,66), (66,74), (74,82)))
        # add a column sample with the filename without extension as the sampleanme
        d.insert(0, 'sample', os.path.splitext(filename)[0])
        # add a column labeling steps A,B,C....
        d.insert(0, 'alphastep', [chr(c) for c in range(ord('A'), ord('A') + len(d))])
        #d = d.set_index( ['sample', 'alphastep'])
        return {'h1':h1, 'h2':h2, 'd':d}



def write_palmag_results(filename, results):
    """
    write results (typically fitted directions of individual samples) to a palmag file
    will output the first ten columns with fixed widths as follows:
    samplename, fitting type, component, D1, I1, D2, I2, analyzed alphanumeric steps, N, a95

    Parameters
    ----------
    filename: string
        filename including path
    results: pandas dataframe
        pandas dataframe with results to write to the file

    Returns
    -------

    """
    with open(filename, "w") as f:
        for row in results.itertuples():
            f.write('{:<14s}{:<3s}{:<3s}{: >6.1f}{: >6.1f}{: >6.1f}{: >6.1f} {: <7.7s}{: >2d}{: >6.1f}\n'.format(*row[1:]))
