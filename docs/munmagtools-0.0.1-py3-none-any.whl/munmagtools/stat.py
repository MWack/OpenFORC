# This is part of munmagtools

# statistic functions in a wide sense

import numpy as np
from random import randrange

def bootStrap(data, nSamples=None, nResults=None):
    """
    bootstrap data of orbitrary dimension

    Parameters
    ----------
    data: numpy data set to bootstrap (first dimension is aussumed to enumerate the individual data sets)
    nSamples: number of samples drawn from data
    nResults: number of results returned

    Returns
    -------
    list of results in the same dimension as data

    """

    if nSamples is None:
        nSamples = len(data)

    if nResults is None:
        nResults = len(data)

    results = []

    for c in range(nResults):
        # draw a random set
        # Todo: maybe this can be done more elegant with 'np.random.choice'
        randset = np.array([data[r] for r in np.random.randint(0, len(data), size=nSamples)])
        # take the mean of the set
        results.append(np.mean(randset, axis=0))

    return np.array(results)
