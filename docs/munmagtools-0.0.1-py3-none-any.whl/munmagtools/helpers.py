# This is file is part of munmagtools
# helpers.py

import numpy as np
# auxiliary functions that can be used in different contexts


def abbreviate_character_sequence(s):
    """
    abbreviate a given sequence of characters (s) by replacing consecutive characters by ranges.
    E.g. ABCD -> A-D or ABCDEFGJKLMOPQRT -> A-GJ-MO-RT

    Parameters
    ----------
    s: str

    Returns
    -------
    abbreviated string

    """
    abb = ''  # the abbreviated string
    c = 0
    s += chr(0) # append 0 character to force processing of the end of the string (no preceding cahracter possible)
    for i in range(1, len(s)):  # go through letter by letter
        if not ord(s[i]) == ord(s[i - 1]) + 1:  # non consecutive character (alphabetical)
            abb += s[i - c - 1] # add isolated or starting character
            if c > 1: abb += '-' # add dash if sequence is more than 2 characters
            if c > 0: abb += s[i - 1] # add end character
            c = 0
        else:
            c += 1  # count number of consecutive characters
    return abb

# define a decorator to convert functions to universal numpy functions
def ufunc(nin, nout):
    def _decorator(func):
        return np.frompyfunc(func, nin, nout)
    return _decorator

#e.g. @ufunc(2, 1)