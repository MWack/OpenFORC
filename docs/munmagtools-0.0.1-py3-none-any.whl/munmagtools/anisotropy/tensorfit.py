# tensorfit.py
# part of munmag tools
# M. Wack 2021

from math import tan, sin, cos, radians, degrees, atan2, asin, exp, log, sqrt, atan
import numpy as np
import scipy.spatial

from munmagtools.transforms import RotateTensor, RVec


def makeDesignMatrix(mdirs, xyz):
    """ create design matrix for anisotropy procedures
    input
    - mdirs: procedure directions e.g. [[D1,I1],[D2,I2],[D3,I3],[D4,I4]]
    - xyz: True --> individual components measured (AARM); False: one component measured (AMS) or ARM without GRM
    """

    # directions in cartesian coordinates
    XYZ = []
    for i in range(len(mdirs)):
        XYZ.append([cos(radians(mdirs[i][0])) * cos(radians(mdirs[i][1])),
                    sin(radians(mdirs[i][0])) * cos(radians(mdirs[i][1])), sin(radians(mdirs[i][1]))])

    # make design matrix for single components (x,y,z)
    B = np.zeros((len(XYZ) * 3, 6), 'f')

    for i in range(len(XYZ)):
        B[i * 3 + 0][0] = XYZ[i][0]
        B[i * 3 + 0][3] = XYZ[i][1]
        B[i * 3 + 0][5] = XYZ[i][2]

        B[i * 3 + 1][3] = XYZ[i][0]
        B[i * 3 + 1][1] = XYZ[i][1]
        B[i * 3 + 1][4] = XYZ[i][2]

        B[i * 3 + 2][5] = XYZ[i][0]
        B[i * 3 + 2][4] = XYZ[i][1]
        B[i * 3 + 2][2] = XYZ[i][2]

    if xyz == True:
        A = B

    else:
        # make design matrix for directional procedure (same direction as applied field)
        A = np.zeros((len(mdirs), 6), 'f')

        for i in range(len(XYZ)):
            A[i] = XYZ[i][0] * B[i * 3 + 0] + XYZ[i][1] * B[i * 3 + 1] + XYZ[i][2] * B[i * 3 + 2]

    return A


# calculate pseude inverse of matrix A
def CalcPseudoInverse(A):
    AT = np.transpose(A)
    ATA = np.dot(AT, A)
    ATAI = np.linalg.inv(ATA)
    B = np.dot(ATAI, AT)

    return B


# calculate eigenvalues and eigenvectors from tensor T, sorted by eigenvalues
def CalcEigenValVec(T):
    # get eigenvalues and eigenvectors
    eigvals, eigvec = np.linalg.eig(T)

    # sort by eigenvalues
    # put eigenvalues and and eigenvectors together in one list and sort this one
    valvec = []
    for i in range(len(eigvals)):
        valvec.append([eigvals[i], np.transpose(eigvec)[i].tolist()])

    # sort eigenvalues and eigenvectors by eigenvalues
    # valvec.sort(lambda x, y: -cmp(x[0], y[0]))  # sort from large to small # broken with python3
    valvec.sort(key=lambda vv: vv[0], reverse=True)  # sort from large to small

    for i in range(len(valvec)):
        eigvals[i] = valvec[i][0]
        eigvec[i] = valvec[i][1]

    return eigvals, eigvec


def CalcAnisoTensor(A, K):
    """ calculate anisotropy tensor
        input: A: design matrix
               K: measured values
        return: dictionary
               R: anisotropy tensor
               eigvals: eigenvalues as array
               n_eigvals: normalized eigenvalues as array
               n_eval1, n_eval2, n_eval3: normalized eigenvalues
               eigvecs: eigenvectors (sorted by eigenvalues)
               I1, I2, I3, D1, D2, D3: inclinations and declinations of eigenvectors
               M: mean magnetization
               Kf: best fit values for K
               L: lineation
               F: foliation
               P: degree of anisotropy?
               P1: corrected degree of anisotropy?
               T:
               U:
               Q:
               E:
               S0: sum of error^2
               stddev: standard deviation
               E12: 12 axis of confidence ellipse
               E23: 23 axis of confidence ellipse
               E13: 13 axis of confidence ellipes
               F0: test for anisotropy (Hext 63)
               F12: test for anisotropy
               F23: test for anisotropy
               QF: quality factor
               """

    aniso_dict = {}
    aniso_dict['msg'] = ''  # put in here any message you want to pass out of this routine

    # calculate pseudo inverse of A
    B = CalcPseudoInverse(A)
    # calculate elements of anisotropy tensor
    s = np.dot(B, K)
    aniso_dict['s'] = s
    # construct symmetric anisotropy tensor R (3x3)
    R = np.array([[s[0], s[3], s[5]], [s[3], s[1], s[4]], [s[5], s[4], s[2]]])


    AnisotropyTensor2Results(R, aniso_dict)

    eigvals = aniso_dict['eigvals']

    # calculate best fit values of K
    Kf = np.dot(A, s)
    aniso_dict['Kf'] = Kf

    # calculate K - Kf --> errors
    d = K - Kf

    # print "measured   \tfit       \ttensor\n"
    # for c in range( len( K)):
    #    print "%.4f   \t %.4f \t %.4f" % (K[c], Kf[c], d[c])

    # calculate sum of errors^2
    S0 = np.dot(d, d)
    aniso_dict['S0'] = S0

    # calculate variance
    var = S0 / (len(d) / 3)
    # len(d) == 18 for 6 directions (12 measured)
    # calc standard deviation
    stddev = sqrt(var)
    aniso_dict['stddev'] = stddev

    # calculate quality factor
    QF = (aniso_dict['P'] - 1) / (stddev / aniso_dict['M'])
    aniso_dict['QF'] = QF

    # calculate confidence ellipses
    # F = 3.89 --> looked up from tauxe lecture 2005; F-table
    f = sqrt(2 * 3.89)
    E12 = abs(degrees(atan(f * stddev / (2 * (eigvals[1] - eigvals[0])))))
    E23 = abs(degrees(atan(f * stddev / (2 * (eigvals[1] - eigvals[2])))))
    E13 = abs(degrees(atan(f * stddev / (2 * (eigvals[2] - eigvals[0])))))

    aniso_dict['E12'] = E12
    aniso_dict['E23'] = E23
    aniso_dict['E13'] = E13

    # Tests for anisotropy (Hext 63)
    F0 = 0.4 * (eigvals[0] ** 2 + eigvals[1] ** 2 + eigvals[2] ** 2 - 3 * ((s[0] + s[1] + s[2]) / 3) ** 2) / var
    F12 = 0.5 * ((eigvals[0] - eigvals[1]) / stddev) ** 2
    F23 = 0.5 * ((eigvals[1] - eigvals[2]) / stddev) ** 2

    aniso_dict['F0'] = F0
    aniso_dict['F12'] = F12
    aniso_dict['F23'] = F23

    return aniso_dict  # return the whole bunch of values

def CalcMeasurements(A, R, xyz=True):
    """ calculate anisotropy tensor
        input: A: design matrix
               R: anisotropy tensor
               xyz: if True, reshape return array to three columns for vectorial measurements
        return: measured values
    """
    S = AnisotropyTensor2S(R)
    K = np.dot(A, S)
    if xyz:
        K = K.reshape([len(K)//3, 3])
    return K

def symmetric(a, tol=1e-14):
    """ check if matrix is symmetric """
    return np.all(np.abs(a-a.T) < tol)

def AnisotropyTensor2S(R):
    """ convert anisotropy tensor to 6 element S vector """
    if not symmetric(R):
        raise ValueError("tensor in not symmertic.")
    # R = np.array([[s[0], s[3], s[5]], [s[3], s[1], s[4]], [s[5], s[4], s[2]]])
    return np.array([R[0][0], R[1][1], R[2][2], R[1][0], R[1][2], R[0][2]])


def AnisotropyTensor2Results(R, aniso_dict):
    aniso_dict['R'] = R
    # calculate eigenvalues and eigenvectors = principal axes
    eigvals, eigvecs = CalcEigenValVec(R)
    aniso_dict['eigvals'] = eigvals
    aniso_dict['eigvecs'] = eigvecs
    # calc inclination and declination of eigenvectors
    (D1, I1, L) = XYZ2DIL(eigvecs[0])
    (D2, I2, L) = XYZ2DIL(eigvecs[1])
    (D3, I3, L) = XYZ2DIL(eigvecs[2])
    # to get consistent plotting, make all inclinations positive
    aniso_dict['D1'], aniso_dict['I1'] = MirrorDirectionToPositiveInclination(D1, I1)
    aniso_dict['D2'], aniso_dict['I2'] = MirrorDirectionToPositiveInclination(D2, I2)
    aniso_dict['D3'], aniso_dict['I3'] = MirrorDirectionToPositiveInclination(D3, I3)
    # calc mean magnetization
    M = (eigvals[0] + eigvals[1] + eigvals[2]) / 3
    aniso_dict['M'] = M
    # calc normalized eigenvalues k
    k = eigvals / (eigvals[0] + eigvals[1] + eigvals[2]) * 3
    aniso_dict['n_eigvals'] = k
    aniso_dict['n_eval1'] = k[0]
    aniso_dict['n_eval2'] = k[1]
    aniso_dict['n_eval3'] = k[2]
    # calc some parameters
    L = k[0] / k[1]
    F = k[1] / k[2]
    P = k[0] / k[2]
    aniso_dict['L'] = L
    aniso_dict['F'] = F
    aniso_dict['P'] = P
    n = []
    neg_eigenvalue = False  # check for negative eigenvalues, log will fail
    for kn in k:
        if kn <= 0:
            neg_eigenvalue = True
            aniso_dict['msg'] = 'Warning: negative eigenvalue!'
            n.append(None)
        else:
            n.append(log(kn))
    if not neg_eigenvalue:
        navg = (n[0] + n[1] + n[2]) / 3

        P1 = exp(sqrt(2 * ((n[0] - navg) ** 2 + (n[1] - navg) ** 2 + (n[2] - navg) ** 2)))
        aniso_dict['P1'] = P1

        T = (2 * n[1] - n[0] - n[2]) / (n[0] - n[2])
        aniso_dict['T'] = T

    else:
        aniso_dict['P1'] = 0  # not possible to calc -> set to 0
        aniso_dict['T'] = None
    U = (2 * k[1] - k[0] - k[2]) / (k[0] - k[2])
    aniso_dict['U'] = U
    Q = (k[0] - k[1]) / ((k[0] + k[1]) / 2 - k[2])
    aniso_dict['Q'] = Q
    E = k[1] ** 2 / (k[0] * k[2])
    aniso_dict['E'] = E
    return eigvals

def Proj_A_on_B_scalar(A, B):
    """
    project a vector A on a vector B and return the scalar result
    see http://en.wikipedia.org/wiki/Vector_projection
    :param A: vector which will be projected on vector B
    :param B: vector defining the direction
    :return: scalar value of the projection A on B
    """
    return np.dot(A, B) / np.linalg.norm(B)

def CalcAnisoTensorProjOptimized(refDirs, K, n=2, history=False):
    """
    optimize reference directions by repeatedly applying the projection method
    finally calculate tensor with full vectorial data based on the optimized reference directions
    :param refDirs: reference directions
    :param K: vectorial measurements
    :param n: number of iterations
    :param history: if true return history of values acquired during iterations
    :return: aniso_dict
    """

    if history:
        history = {}
        history['refDirs'] = []  # will hold reference directions for each iteration
        history['proj'] = []  # will hold results for projected calculation for each iteration
        history['vect'] = []  # will hold results for vectorial calculation for each iteration

    for i in range(n):
        #print(f"i={i}, refDirs={refDirs}")
        A = makeDesignMatrix(refDirs, xyz=False)
        #print("---", refDirs[i])
        Kproj = [Proj_A_on_B_scalar(K[i * 3:i * 3 + 3], DIL2XYZ(np.append(refDirs[i], 1))) for i in range(len(refDirs))]
        try:
            ad = CalcAnisoTensor(A, Kproj)
        except np.linalg.LinAlgError:
            break  # this happens if tensors do not converge and get bigger and bigger, typically you need at least 20 iterations
        if history:
            history['proj'].append(ad)
            Av = makeDesignMatrix(refDirs, xyz=True)  # make vectorial design matrix just see convergence
            history['vect'].append(CalcAnisoTensor(Av, K))
            history['refDirs'].append(refDirs)

        refDirs = CalcReferenceDirection(ad['s'], K)

    # do full vector tensor calculation with optimized reference directions
    A = makeDesignMatrix(refDirs, xyz=True)
    res = CalcAnisoTensor(A, K)
    res['opt_ref_dirs'] = np.array(refDirs)
    if history:
        history['refDirs'] = np.array(history['refDirs'])  # 3D array
        res['history'] = history
    return res


def CalcReferenceDirection(s, K):
    """
    calculate reference directions from given anisotropy tensor (s1 to s6) and the measured values
    :param s: vector containing the six independent tensor elements
    :param K: measured values, must have length multiple of 3 assuming cyclic xyz components
    :return: reference directions
    """
    if len(K) % 3 != 0:
        raise RuntimeError('CalcReferenceDirection: K must be list of values with length multiple of 3')

    ref_dirs = []

    # calculate needed matrix
    n = s[0] * s[1] * s[2] - s[0] * s[4] ** 2 - s[1] * s[5] ** 2 - s[2] * s[3] ** 2 + 2 * s[3] * s[4] * s[5]
    m = 1.0 / n * np.matrix([[s[1] * s[2] - s[4] ** 2, s[4] * s[5] - s[2] * s[3], s[3] * s[4] - s[1] * s[5]],
                             [(s[4] * s[5] - s[2] * s[3]), (s[0] * s[2] - s[5] ** 2), (s[3] * s[5] - s[0] * s[4])],
                             [(s[3] * s[4] - s[1] * s[5]), (s[3] * s[5] - s[0] * s[4]), (s[0] * s[1] - s[3] ** 2)]])

    # calculate cartesian components of reference directions for each block of 3 procedure values
    for c in range(len(K) // 3):
        refdir_cart = np.dot(m, K[c * 3:c * 3 + 3])
        refdir_cart = np.array(refdir_cart).flatten()
        # if refdir_cart[2] > 1 or refdir_cart[2] < -1:
        # if 1:
        #    print n
        #    print m
        #    print refdir_cart
        #    print sqrt(refdir_cart[0]**2 + refdir_cart[1]**2)
        Iref = np.degrees(
            atan2(refdir_cart[2], sqrt(refdir_cart[0] ** 2 + refdir_cart[1] ** 2)))  # I = atan2(Z, sqrt(X**2+Y**2)
        Dref = np.degrees(atan2(refdir_cart[1], refdir_cart[0]))  # D = atan2( Y, X)
        if Dref < 0:
            Dref += 360
        ref_dirs.append([Dref, Iref])

    return ref_dirs

def Eigenval2AnisoTensor( eigvals):
    """ create anisotropy tensor based on three given eigenvalues """
    # construct symmetric anisotropy tensor R (3x3)
    R = np.zeros([3, 3])  # create 3x3 matrix filled with zeros
    np.fill_diagonal(R, eigvals)  # fill diagonal with eigen values
    return R


def eigenvect2DI_array(vectors):
    """ convert list of (eigen)vectors to arrays of inclinations and declinations on lower hemisphere (positive inclination)"""
    _decs = []  # list of declinations of vectors
    _incs = []  # list of inclinations of vectors
    for v in vectors:
        # transform eigenvectors to anisotropy directions
        (D, I, L) = XYZ2DIL(v)
        # to get consistent plotting, make all inclinations positive
        D, I = MirrorDirectionToPositiveInclination(D, I)
        _decs.append(D)
        _incs.append(I)

    return _decs, _incs


def XYZ2DIL(XYZ):
    """ convert XYZ to dec, inc, length """
    DIL = []
    L = np.linalg.norm(XYZ)
    # L=sqrt(XYZ[0]**2+XYZ[1]**2+XYZ[2]**2) # calculate resultant vector length
    D = degrees(atan2(XYZ[1], XYZ[0]))  # calculate declination taking care of correct quadrants (atan2)
    if D < 0: D = D + 360.  # put declination between 0 and 360.
    if D > 360.: D = D - 360.
    DIL.append(D)  # append declination to Dir list
    I = degrees(asin(XYZ[2] / L))  # calculate inclination (converting to degrees)
    DIL.append(I)  # append inclination to Dir list
    DIL.append(L)  # append vector length to Dir list
    return DIL


def DIL2XYZ(DIL):
    """Converts a tuple of D,I,L components to a tuple of x,y,z."""
    (D, I, L) = DIL
    H = L * cos(radians(I))
    X = H * cos(radians(D))
    Y = H * sin(radians(D))
    Z = H * tan(radians(I))
    return (X, Y, Z)

def MirrorDirectionToNegativeInclination(dec, inc):
    if inc > 0:
        return (dec + 180) % 360, -inc
    else:
        return dec, inc


def MirrorDirectionToPositiveInclination(dec, inc):
    if inc < 0:
        return (dec + 180) % 360, -inc
    else:
        return dec, inc


def MirrorVectorToNegativeInclination(x, y, z):
    if z > 0:
        return -x, -y, -z
    else:
        return x, y, z


def MirrorVectorToPositiveInclination(x, y, z):
    if z < 0:
        return -x, -y, -z
    else:
        return x, y, z


def CreateRandomTensor(evscatter=.1, rotScatter=360):
    """
    Return a random tensor
    """
    # create a random tensor
    Rrand = Eigenval2AnisoTensor(1 + (np.random.random_sample(size=3) - 0.5) * 2 * evscatter)
    # do random rotation
    # Rrand = core2geoTensor(Rrand, coreaz=np.random.random_sample() * 360, coredip=np.random.random_sample() * 180)
    Rrand = RotateTensor(Rrand, scipy.spatial.transform.Rotation.from_rotvec(RVec(rotScatter)).as_matrix())

    return Rrand