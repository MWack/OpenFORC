# this is part of munmagtools
# written by Michael Wack 2021

import numpy as np
from numpy import dot, radians, cos, sin, frompyfunc, array



def CreateRotMat(angles):
    """Generate rotation matrix out of 3 Euler angles (a, b, c)."""

    A = ZRot(angles[0])
    B = XRot(angles[1])
    C = ZRot(angles[2])

    return dot(A, dot(B, C))


def XRot(xrot):
    """Generate rotation matrix for a rotation of xrot degrees around the x-axis"""
    a = radians(xrot)

    return array(((1, 0, 0), (0, cos(a), -sin(a)), (0, sin(a), cos(a))))


def YRot(yrot):
    """Generate rotation matrix for a rotation of yrot degrees around the y-axis"""
    a = radians(yrot)

    return array(((cos(a), 0, sin(a)), (0, 1, 0), (-sin(a), 0, cos(a))))


def ZRot(zrot):
    """Generate rotation matrix for a rotation of zrot degrees around the z-axis"""
    a = radians(zrot)

    return array(((cos(a), -sin(a), 0), (sin(a), cos(a), 0), (0, 0, 1)))


def RotateVector(v, rotmat):
    """Rotate a vector v = (x,y,z) about 3 Euler angles (x-convention) defined by matrix rotmat."""
    # return resulting vector
    return dot(v, rotmat)


def RotateTensor(T, rotmat):
    """ rotate 3x3 tensor about 3 Euler angles (x-convention) defined by matrix rotmat."""
    # return resulting tensor
    return dot(rotmat.T, dot(T, rotmat))

# function to create random numbers between -maxdev and +maxdev
def ran(maxdev, normal=False):
    if normal:
        return np.random.normal(scale=maxdev//2)
    else:
        return (np.random.random_sample() - 0.5) * 2 * maxdev

def RVec(rot_scatter, rot_angle=0, rot_axis=None, normal=False):
    """ create random or specific rotation vector
    param rot_scatter: random range of rotation angle
    param rot_angle: rotation in degrees
    param rot_axis: if None use random direction, else 3x1 vector to specify rotation axis
    param normal: use normal distribution for random values"""
    if rot_axis is None:
        v = np.random.rand(3)
    else:
        v = rot_axis
    return v / np.linalg.norm(v) * np.radians(ran(rot_scatter, normal=normal) + rot_angle)  # random rotation vector + systematic rotation


# coordinate transformations

def core2geo(core_xyz, coreaz, coredip, invdrilldir=False):
    """convert core coordinates to geographic coordinates"""
    # if invdrilldir == True -> z-mark done or samples inserted in the wrong way during measurement -->> adapt coreaz and and coredip accordingly
    if invdrilldir:
        coreaz = (coreaz + 180) % 360
        coredip = 180 - coredip
    # rotate around y-axis to compensate core dip
    xyz = RotateVector(core_xyz[0:3], YRot(-coredip))
    # rotate around z-axis
    geo_xyz = RotateVector(xyz, ZRot(-coreaz))

    # do we have additional elements? Append the 4th (e.g. label)
    if len(core_xyz) > 3:
        geo_xyz = (geo_xyz[0], geo_xyz[1], geo_xyz[2], core_xyz[3])

    return geo_xyz


def core2geoTensor(core_T, coreaz, coredip, invdrilldir=False):
    """convert core coordinates to geographic coordinates"""
    # if invdrilldir == True -> z-mark done or samples inserted in the wrong way during measurement -->> adapt coreaz and and coredip accordingly
    if invdrilldir:
        coreaz = (coreaz + 180) % 360
        coredip = 180 - coredip
    # rotate around y-axis to compensate core dip
    T = RotateTensor(core_T, YRot(-coredip))
    # rotate around z-axis
    geo_T = RotateTensor(T, ZRot(-coreaz))
    return geo_T


def geo2bed(geo_xyz, bedaz, beddip):
    """convert geographic coordinates to bedding corrected coordinates"""
    # TEST: XYZ2DIL( core2bed( (.3,.825,1.05), 40, 20)) -> D=62, I=32 (Butler S.72)
    # rotate around z-axis until strike is along y axis of fixed system
    xyz = RotateVector(geo_xyz[0:3], ZRot(bedaz))
    # now rotate around y-axis to compensate bed dip
    xyz = RotateVector(xyz, YRot(-beddip))
    # rotate back around z-axis
    bed_xyz = RotateVector(xyz, ZRot(-bedaz))

    # do we have additional elements? Append the 4th (e.g. label)
    if len(geo_xyz) > 3:
        bed_xyz = (bed_xyz[0], bed_xyz[1], bed_xyz[2], geo_xyz[3])

    return bed_xyz


def geo2bedTensor(geo_T, bedaz, beddip):
    """convert geographic coordinates to bedding corrected coordinates"""
    # rotate around z-axis until strike is along y axis of fixed system
    T = RotateTensor(geo_T, ZRot(bedaz))
    # now rotate around y-axis to compensate bed dip
    T = RotateTensor(T, YRot(-beddip))
    # rotate back around z-axis
    bed_T = RotateTensor(T, ZRot(-bedaz))

    return bed_T
